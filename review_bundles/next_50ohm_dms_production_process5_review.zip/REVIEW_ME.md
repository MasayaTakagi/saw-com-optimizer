# Stage 3.1 review summary

This bundle contains finite cold-seed evidence only; it does not claim a global optimum.

- Command: `python -m sawopt.optimization.stage32_study --config configs/studies/next_50ohm_dms_production.yaml --run runs/next_50ohm_dms_production`
- Impedance: 50.0 ohm
- Budgets (unique decoded designs): None
- Wirings: ['center_outer_same', 'outer_ports']
- Cold seeds: [20260909, 20260910, 20260911, 20260912, 20260913]

## Convergence

- `center_outer_same` status: `likely_underoptimized`
  - final seed IQR: 0.24225318145044517
  - common validation gap: 0.0
  - best-candidate polish improvement: 0.0
  - last paired median improvement: 8.712441337266341e-07
- `outer_ports` status: `converged`
  - final seed IQR: 0.037534715058445745
  - common validation gap: 0.0003391757224804337
  - best-candidate polish improvement: 0.0
  - last paired median improvement: 0.0

## Budget summaries

- `center_outer_same` / 500: best primary=1.9443083101350145, median primary=2.220372891220142
- `center_outer_same` / 1000: best primary=1.839207193779965, median primary=1.8515167322012167
- `center_outer_same` / 2000: best primary=1.0999417911235017, median primary=1.599698413829684
- `center_outer_same` / 4000: best primary=1.0994978013237877, median primary=1.5967118272328893
- `center_outer_same` / 8000: best primary=1.0994978013237877, median primary=1.5967115155714695
- `outer_ports` / 500: best primary=2.445108550729137, median primary=2.8213706971236294
- `outer_ports` / 1000: best primary=2.298826744883449, median primary=2.6101278149497724
- `outer_ports` / 2000: best primary=1.8834871845663899, median primary=1.960881820530295
- `outer_ports` / 4000: best primary=1.8834287028932621, median primary=1.9087700238629028
- `outer_ports` / 8000: best primary=1.8834287028932621, median primary=1.9087700238629028

## Runtime and validation

- Last significant improvement location is recorded in every trial JSON.
- Performance-gate speedup: `{}`
- Wall time: 1230.9939391613007 s
- Solved frequency point counts and logging I/O time are in `convergence_trials.csv`.
- Test status: `{"command": "PYTHONPATH=src python -m unittest discover -v", "passed": 66, "failed": 0, "exit_code": 0, "elapsed_s": 66.46210026741028}`; exact output is `tests/unittest.txt`.

## Known limitations

- Hypothetical COM remains unvalidated for production design.
- Finite budget/seed evidence does not claim a global optimum.
- The benchmark does not establish a global optimum.
- Production impedance/topology sweeps require review of this certificate first.
- Source hash from the run manifest: `61e6212062ab9d13e8925c7a2a428b3e6e180522aae3a5a192262e6435373053`
