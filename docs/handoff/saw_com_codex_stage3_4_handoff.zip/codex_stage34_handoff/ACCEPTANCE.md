# Stage 3.4 Acceptance

## Source / refactor safety

- [ ] Current post-refactor checkout identified before editing.
- [ ] New behavior added to canonical modules, not compatibility wrappers.
- [ ] Refactor dependency rules remain satisfied.
- [ ] Existing zero-progress 4-attempt recovery semantics preserved.
- [ ] Source hash frozen from preflight start through production start.

## Boundary logic

- [ ] Ordinary persistent multi-seed pressure still works.
- [ ] Elite boundary detector is wired into the production coordinator.
- [ ] One elite seed may request a probe but cannot directly expand.
- [ ] Elite expansion requires >=2 positive seeds.
- [ ] Elite expansion requires >=50% positive probe fraction.
- [ ] Elite expansion requires median primary improvement > configured threshold.
- [ ] Integer boundary zone includes lower+1 / upper-1 step as configured.
- [ ] Hard bounds are never crossed.
- [ ] Bound expansion increments design-space version and resets convergence evidence.
- [ ] New-region population injection is preserved.

## Stagnation recovery

- [ ] Duplicate ratio is interval-based.
- [ ] Recovery requires both high duplicate ratio and stale significant improvement.
- [ ] Recovery is capped per design-space version.
- [ ] Recovery reuses existing continuation diversification semantics.
- [ ] No duplicate recovery occurs in the same checkpoint as bound-expansion injection.
- [ ] Stagnation events are persisted.

## Checkpoints / convergence

- [ ] Stage 3.4 checkpoint ladder resolves exactly as configured.
- [ ] Production cannot stop as converged before 16000.
- [ ] Optional 32000 escalation occurs only when needed.
- [ ] Same-design-space-version rule remains enforced for plateau evidence.
- [ ] Unique-design budget accounting remains exact/acceptable.

## Tests

- [ ] Targeted continuation/bound tests pass.
- [ ] Refactor architecture tests pass.
- [ ] Full repository test suite passes.
- [ ] 5-process deterministic/parity expectations remain green.
- [ ] Review bundle self-test passes.

## Production

- [ ] 50 Ω / `center_outer_same` only.
- [ ] Five cold seeds.
- [ ] Five process workers, one BLAS thread each.
- [ ] Legacy SciPy DE remains production optimizer.
- [ ] No COM/specification changes were made to improve results.

## Review bundle

- [ ] Fresh post-refactor Stage 3.4 patch included.
- [ ] Boundary and elite-probe events included.
- [ ] Stagnation events included.
- [ ] Design-space versions/active bounds included.
- [ ] Exact configs/source/test logs included.
- [ ] All bundle hashes validate.
