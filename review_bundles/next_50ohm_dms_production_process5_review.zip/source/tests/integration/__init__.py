"""Study orchestration integration tests."""
