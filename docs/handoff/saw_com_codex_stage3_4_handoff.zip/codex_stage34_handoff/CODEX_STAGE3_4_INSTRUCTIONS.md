# Stage 3.4 — Elite-boundary recovery and convergence follow-up

## 0. Mission

Continue the 50 Ω `center_outer_same` convergence study using the current, refactored repository as the only implementation source of truth.

The previous 16k production result remained `likely_underoptimized`. The decisive observation was not merely that budget was insufficient: the best three seeds ended at `io_idt_pairs=15`, the active lower soft bound, while an explicit probe at `io_idt_pairs=10` improved 4/5 seeds and produced a best probed max-violation near 1.04. The current production coordinator has an elite-boundary detector, but that diagnostic was not wired into the actual expansion path.

This stage must fix that coordination defect, improve checkpoint resolution, and add conservative duplicate/stagnation recovery without changing COM physics or switching optimizer family.

**Production optimizer remains Legacy SciPy DE. Do not re-open the L-SHADE decision in this stage.**

---

# 1. Source-of-truth rule — critical

A refactor occurred after the source snapshot used to construct the reference diff in this handoff.

Therefore:

1. Treat the **current checkout in Codex** as source of truth.
2. Do **not** blindly run `git apply` on `patch/REFERENCE_ONLY_stage3_4_pre_refactor.patch` unless the repository still exactly matches its base snapshot.
3. The reference patch was generated and unit-tested against the latest experiment review snapshot available to the reviewer (`source_hash=17290fc6a0191b2eb08ba7e5678c4e44b34e5d99b63187cef752c171cff304ad`, git commit `0cc146ef72eaae27d8f77c52c7886ae21103931e`). It is a behavior-level reference, not an instruction to restore old architecture.
4. First locate the current canonical implementations with `rg`/symbol search.
5. Apply the same semantic changes to the **post-refactor canonical modules**.
6. Generate a fresh `git diff --binary` from the current checkout after implementation. That fresh diff is the actual Stage 3.4 patch.

Expected post-refactor ownership from the refactor plan:

- continuation/bound-expansion policy → `src/sawopt/studies/continuation.py`
- lower-level population construction/injection primitives → `src/sawopt/optimization/population.py` if extracted
- shared config loader → `src/sawopt/io/config.py`
- old `optimization/stage32_study.py` should be a compatibility wrapper if the refactor reached Phase 4

**Do not put new behavior into an obsolete compatibility wrapper when a canonical refactored module exists.**

Before editing, record:

```bash
git status --short
git rev-parse HEAD
rg -n "class ContinuationTrajectory|detect_elite_boundary_probe|boundary_probe|detect_boundary_pressure|no_new_unique_designs" src tests
```

Save this mapping to `runs/stage3_4_preflight/current_code_map.txt`.

---

# 2. Preserve current behavior

Do not change:

- COM equations/sign convention
- Y/S/network calculations
- hypothetical provider values
- passband/stopband specification
- feasibility-first ranking
- integer decoding/canonical cache identity
- unique-design accounting
- 5-seed process parallelism
- the existing zero-progress retry/diversification behavior
- the existing 4-attempt zero-progress recovery semantics introduced before the refactor
- current bound hard limits unless explicitly configured below

The refactor plan explicitly classifies the zero-progress DE retry/diversification as continuation-study policy. Preserve it in the canonical continuation module.

---

# 3. Fix A — wire elite-boundary diagnosis into production expansion

## 3.1 Current defect

The previous implementation contains an elite-boundary detector, but the production continuation coordinator only consumes ordinary multi-seed pressure. A best or elite seed can therefore request a diagnostic probe without the request ever affecting the active soft bound.

This is exactly what matters after the 16k result: all-seed boundary occupancy was below the 80% trigger even though the leading seeds were concentrated at the lower bound.

## 3.2 Required behavior

Keep the existing normal path:

```text
persistent multi-seed boundary pressure
    -> boundary probe
    -> positive probe
    -> expand soft bound
```

Add a second path:

```text
materially superior elite candidate at boundary
    -> request probe only
    -> evaluate the proposed next bound step across all cold seeds
    -> require multi-seed probe consensus
    -> expand only if consensus is positive
```

A single seed may request a probe but **must never expand a bound by itself**.

## 3.3 Probe diagnostics

For every probed seed save:

- before primary metric
- after primary metric
- improvement
- validated/search rank as already available

Aggregate:

- `positive_count`
- `positive_fraction`
- `median_improvement`
- `best_improvement`

Recommended default elite expansion gate:

```yaml
elite_probe_min_positive_seeds: 2
elite_probe_min_positive_fraction: 0.50
elite_probe_median_improvement_threshold: 0.02
```

All three must pass.

The existing `probe_improvement_threshold` remains 0.02 unless current config says otherwise.

## 3.4 Event recording

Record separate events:

```text
elite_boundary_probe
bound_expansion(reason=elite_probe_consensus)
hard_bound_limited
boundary_probe_no_improvement
```

Do not hide elite expansion inside the ordinary pressure event.

---

# 4. Fix B — checkpoint schedule resolution

The geometric schedule `500 -> 1000 -> 2000 -> 4000 -> 8000 -> 16000` was too coarse late in the search. The 8k→16k interval hid late basin transitions and delayed boundary diagnosis.

For this Stage 3.4 production run use:

```text
500
1000
2000
3000
4000
6000
8000
10000
12000
14000
16000
optional 32000 only if still unresolved
```

For this stage it is acceptable for these to remain full continuation checkpoints rather than introducing a new lightweight checkpoint abstraction. Optimizer correctness and boundary responsiveness have priority over micro-optimizing validation overhead.

Add/configure:

```yaml
minimum_convergence_budget: 16000
```

A temporary plateau before 16k must not terminate this experiment early.

If a bound expansion occurs, convergence evidence from the prior design-space version remains invalid for the new version, exactly as before.

Do not combine rows from different `design_space_version` values when certifying plateau.

---

# 5. Fix C — duplicate/stagnation recovery before total zero progress

## 5.1 Motivation

One 16k seed generated approximately 251k objective calls with roughly 235k cache hits. The existing zero-progress retry path only reacts when a DE segment adds no new unique designs at all. It does not react to a segment that technically makes progress but is overwhelmingly duplicate-dominated.

## 5.2 Conservative recovery gate

At coordinator checkpoints calculate **interval**, not lifetime, duplicate ratio:

```text
interval_duplicate_fraction = delta_cache_hits / max(delta_objective_calls, 1)
```

Trigger diversity refresh only when all conditions pass:

```yaml
stagnation_recovery:
  enabled: true
  duplicate_fraction_threshold: 0.80
  minimum_interval_objective_calls: 500
  unique_evaluations_since_improvement: 2000
  max_recoveries_per_design_space_version: 2
```

Recovery should reuse the already validated continuation-study population-refresh behavior. Do not invent a second DE algorithm.

Preserve approximately the best/old quarter of the population and rebuild the rest using current active bounds and current trajectory RNG, as the existing zero-progress recovery already does.

Do not trigger duplicate recovery in the same checkpoint where a bound expansion already injected new-region diversity.

Reset interval duplicate diagnostics after a bound expansion.

Record `stagnation_events` including:

- wiring
- seed
- budget
- design-space version
- interval objective calls
- interval cache hits
- duplicate fraction
- unique evaluations since last significant improvement

---

# 6. Config changes

Create a new reusable fragment rather than mutating historical Stage 3.2 configs in-place.

Reference values are included in:

```text
config/stage3_4_center_bound_recovery_fragment.yaml
```

Create/update the current repository equivalent of:

```text
configs/studies/next_50ohm_center_outer_same_stage34.yaml
```

After the refactor, use the new config/experiment layout if applicable. Preserve current fragment merge ordering and last-fragment-wins behavior.

Production settings:

- impedance: 50 Ω / 50 Ω
- wiring: `center_outer_same`
- seeds: 20260909..20260913 (same five seeds)
- workers: 5 processes
- BLAS threads/process: 1
- optimizer: legacy SciPy DE
- auto-bound: enabled
- auto-shrink: disabled
- `io_idt_pairs` soft/hard sequence remains `20 -> 15 -> 10 -> 8` lower side
- optional escalation: 32000

---

# 7. Required tests before production

Add tests at the **new refactored canonical test locations**. Do not reintroduce Stage-number dependencies if the refactor removed them.

Mandatory tests:

1. elite seed can request a probe without directly expanding;
2. elite-requested probe requires >=2 positive seeds;
3. elite-requested probe requires configured positive fraction;
4. elite-requested probe requires positive median improvement;
5. one positive seed cannot expand a bound;
6. integer boundary zone still includes lower+1 step;
7. normal multi-seed persistent pressure still works unchanged;
8. hard bound is never crossed;
9. bound expansion injects candidates into newly opened region;
10. duplicate-stagnation recovery uses interval counters;
11. duplicate recovery is capped per design-space version;
12. bound expansion suppresses duplicate recovery in the same checkpoint;
13. minimum convergence budget prevents early production stop;
14. historical zero-progress 4-attempt retry characterization remains green;
15. resolved Stage 3.4 config has 5 production workers and optional max 32000;
16. all existing refactor regression tests remain green.

Run targeted tests, then full suite.

---

# 8. Preflight and patch production

After implementation:

```bash
git diff --check
PYTHONPATH=src pytest -q <targeted continuation/bound tests>
PYTHONPATH=src pytest -q
```

If the project still uses unittest as an official acceptance path, also run:

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

Generate:

```text
runs/stage3_4_preflight/
  current_code_map.txt
  source_hash_before.txt
  source_hash_after.txt
  test_log.txt
  resolved_config.json
  stage3_4.patch        # fresh diff from the current refactored checkout
```

Source hash must be frozen through preflight.

Only after all tests pass may production start.

---

# 9. Production command

Use the current post-refactor CLI/study registry if available. Do not revive an old Stage CLI solely to match historical text.

Conceptually:

```text
run continuation/convergence experiment
config = next_50ohm_center_outer_same_stage34
workers = 5
```

One blocking command should execute:

- 5 cold seeds in 5 processes
- checkpoints/escalation
- boundary diagnosis/probes
- bound expansion
- duplicate recovery
- convergence classification
- review bundle creation

Do not poll repeatedly from Codex.

---

# 10. Stop after center_outer_same

Do not run `outer_ports` or 20–200 Ω in this stage.

The next review must first decide whether `center_outer_same` reaches:

```text
converged
hard_bound_limited
likely_underoptimized
inconclusive
```

and whether `io_idt_pairs` expands 15→10 (and possibly 10→8) under the corrected policy.
