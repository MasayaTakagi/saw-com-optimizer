# Stage 3.4 handoff

Read in this order:

1. `CODEX_STAGE3_4_INSTRUCTIONS.md`
2. `PATCH_PORTING_GUIDE.md`
3. `EXPERIMENT_PLAN.md`
4. `ACCEPTANCE.md`
5. config examples
6. `patch/REFERENCE_ONLY_stage3_4_pre_refactor.patch`

Important: the included unified diff is **reference-only** because the repository was refactored after the reviewed source snapshot. The Codex task is to port the tested semantic changes to the latest canonical modules, then generate a fresh patch from the actual current checkout.
