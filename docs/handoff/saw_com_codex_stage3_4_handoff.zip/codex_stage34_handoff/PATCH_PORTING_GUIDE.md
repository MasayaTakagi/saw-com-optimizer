# Stage 3.4 patch porting guide

## Why the included diff is reference-only

The reviewer had access to the exact source snapshot bundled with the latest 16k experiment, but not to the final post-refactor repository bytes. A completed/refined architecture may have moved continuation logic from:

```text
sawopt/optimization/stage32_study.py
```

to the canonical post-refactor location:

```text
sawopt/studies/continuation.py
```

The refactor plan explicitly assigns the zero-progress/retry/diversification policy to the continuation study and suggests lower-level population primitives under `optimization/population.py`.

Therefore `patch/REFERENCE_ONLY_stage3_4_pre_refactor.patch` must be treated as a tested semantic reference, not blindly applied to a refactored tree.

## Mapping

Port these symbols to their current canonical owners:

| Reference symbol | Expected post-refactor owner |
|---|---|
| `detect_boundary_pressure` | `studies/continuation.py` or continuation-bound policy module |
| `detect_elite_boundary_probe` | same continuation policy owner |
| `boundary_probe` | same continuation policy owner, using public problem evaluator |
| `elite_probe_consensus` | same continuation policy owner |
| `ContinuationTrajectory` | `studies/continuation.py` |
| `_diversify_after_stagnation` policy | `studies/continuation.py` |
| `_build_population`, region injection primitive | `optimization/population.py` if extracted |
| config resolution | current `io/config.py` / experiment config system |
| Stage 3.2 tests | current `tests/unit/studies/...` continuation tests |

Do not move SAW-specific bound decisions into generic optimizer backends.

## Rebase procedure

1. Search current tree for the symbols above.
2. Confirm current tests characterize pre-existing behavior.
3. Re-implement each reference hunk at the canonical location.
4. Keep old compatibility wrappers thin.
5. Add current-architecture tests.
6. Run `git diff --check`.
7. Save the **fresh current-tree diff** as `runs/stage3_4_preflight/stage3_4.patch`.
8. That fresh patch, not the included reference patch, is the patch submitted with the next review bundle.
