# Stage 3.1 review summary

This bundle contains finite cold-seed evidence only; it does not claim a global optimum.

- Command: `python -m sawopt.optimization.stage32_study --config configs/studies/next_50ohm_center_outer_same_16000.yaml --run runs/next_50ohm_center_outer_same_16000`
- Impedance: 50.0 ohm
- Budgets (unique decoded designs): None
- Wirings: ['center_outer_same']
- Cold seeds: [20260909, 20260910, 20260911, 20260912, 20260913]

## Convergence

- `center_outer_same` status: `likely_underoptimized`
  - final seed IQR: 0.49721371423550975
  - common validation gap: 0.00015860917354793003
  - best-candidate polish improvement: 0.0
  - last paired median improvement: 1.2172041152780366e-11

## Budget summaries

- `center_outer_same` / 500: best primary=1.9443083101350145, median primary=2.220372891220142
- `center_outer_same` / 1000: best primary=1.839207193779965, median primary=1.8515167322012167
- `center_outer_same` / 2000: best primary=1.0999417911235017, median primary=1.599698413829684
- `center_outer_same` / 4000: best primary=1.0994978013237877, median primary=1.5967118272328893
- `center_outer_same` / 8000: best primary=1.0994978013237877, median primary=1.5967115155714695
- `center_outer_same` / 16000: best primary=1.086841417894861, median primary=1.3160907750010336

## Runtime and validation

- Last significant improvement location is recorded in every trial JSON.
- Performance-gate speedup: `{}`
- Wall time: 1020.7919826507568 s
- Solved frequency point counts and logging I/O time are in `convergence_trials.csv`.
- Test status: `{"command": "PYTHONPATH=src python -m unittest discover -v", "exit_code": 0, "passed": 66, "failed": 0, "elapsed_s": 66.38314485549927}`; exact output is `tests/unittest.txt`.

## Known limitations

- Hypothetical COM remains unvalidated for production design.
- Finite budget/seed evidence does not claim a global optimum.
- The benchmark does not establish a global optimum.
- Production impedance/topology sweeps require review of this certificate first.
- Source hash from the run manifest: `17290fc6a0191b2eb08ba7e5678c4e44b34e5d99b63187cef752c171cff304ad`
