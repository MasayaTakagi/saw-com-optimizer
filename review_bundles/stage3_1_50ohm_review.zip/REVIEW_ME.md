# Stage 3.1 review summary

This bundle contains finite cold-seed evidence only; it does not claim a global optimum.

- Command: `python -m sawopt.optimization.convergence_study --config configs/studies/stage3_convergence_50ohm.yaml --run runs/stage3_1_50ohm`
- Impedance: 50.0 ohm
- Budgets (unique decoded designs): [500, 1000, 2000, 4000]
- Wirings: ['outer_ports', 'center_outer_same']
- Cold seeds: [20260908, 20260909, 20260910, 20260911, 20260912]

## Convergence

- `outer_ports` status: `likely_underoptimized`
  - final seed IQR: 0.16307555783713923
  - common validation gap: 0.0
  - best-candidate polish improvement: 0.037419528880903385
  - last paired median improvement: 0.006711924319054763
  - last significant improvement positions: {"500": [{"seed": 20260908, "unique_evaluation": 323, "fraction_of_budget": 0.646}, {"seed": 20260909, "unique_evaluation": 265, "fraction_of_budget": 0.53}, {"seed": 20260910, "unique_evaluation": 346, "fraction_of_budget": 0.692}, {"seed": 20260911, "unique_evaluation": 338, "fraction_of_budget": 0.676}, {"seed": 20260912, "unique_evaluation": 333, "fraction_of_budget": 0.666}], "1000": [{"seed": 20260908, "unique_evaluation": 547, "fraction_of_budget": 0.547}, {"seed": 20260909, "unique_evaluation": 646, "fraction_of_budget": 0.646}, {"seed": 20260910, "unique_evaluation": 676, "fraction_of_budget": 0.676}, {"seed": 20260911, "unique_evaluation": 678, "fraction_of_budget": 0.678}, {"seed": 20260912, "unique_evaluation": 698, "fraction_of_budget": 0.698}], "2000": [{"seed": 20260908, "unique_evaluation": 733, "fraction_of_budget": 0.3665}, {"seed": 20260909, "unique_evaluation": 646, "fraction_of_budget": 0.323}, {"seed": 20260910, "unique_evaluation": 676, "fraction_of_budget": 0.338}, {"seed": 20260911, "unique_evaluation": 814, "fraction_of_budget": 0.407}, {"seed": 20260912, "unique_evaluation": 1137, "fraction_of_budget": 0.5685}], "4000": [{"seed": 20260908, "unique_evaluation": 733, "fraction_of_budget": 0.18325}, {"seed": 20260909, "unique_evaluation": 3465, "fraction_of_budget": 0.86625}, {"seed": 20260910, "unique_evaluation": 676, "fraction_of_budget": 0.169}, {"seed": 20260911, "unique_evaluation": 814, "fraction_of_budget": 0.2035}, {"seed": 20260912, "unique_evaluation": 1137, "fraction_of_budget": 0.28425}]}
- `center_outer_same` status: `likely_underoptimized`
  - final seed IQR: 0.005240329366867691
  - common validation gap: 0.0
  - best-candidate polish improvement: 0.0
  - last paired median improvement: 0.003838366499405943
  - last significant improvement positions: {"500": [{"seed": 20260908, "unique_evaluation": 265, "fraction_of_budget": 0.53}, {"seed": 20260909, "unique_evaluation": 401, "fraction_of_budget": 0.802}, {"seed": 20260910, "unique_evaluation": 464, "fraction_of_budget": 0.928}, {"seed": 20260911, "unique_evaluation": 342, "fraction_of_budget": 0.684}, {"seed": 20260912, "unique_evaluation": 325, "fraction_of_budget": 0.65}], "1000": [{"seed": 20260908, "unique_evaluation": 589, "fraction_of_budget": 0.589}, {"seed": 20260909, "unique_evaluation": 521, "fraction_of_budget": 0.521}, {"seed": 20260910, "unique_evaluation": 602, "fraction_of_budget": 0.602}, {"seed": 20260911, "unique_evaluation": 857, "fraction_of_budget": 0.857}, {"seed": 20260912, "unique_evaluation": 943, "fraction_of_budget": 0.943}], "2000": [{"seed": 20260908, "unique_evaluation": 1075, "fraction_of_budget": 0.5375}, {"seed": 20260909, "unique_evaluation": 866, "fraction_of_budget": 0.433}, {"seed": 20260910, "unique_evaluation": 768, "fraction_of_budget": 0.384}, {"seed": 20260911, "unique_evaluation": 856, "fraction_of_budget": 0.428}, {"seed": 20260912, "unique_evaluation": 905, "fraction_of_budget": 0.4525}], "4000": [{"seed": 20260908, "unique_evaluation": 3272, "fraction_of_budget": 0.818}, {"seed": 20260909, "unique_evaluation": 866, "fraction_of_budget": 0.2165}, {"seed": 20260910, "unique_evaluation": 768, "fraction_of_budget": 0.192}, {"seed": 20260911, "unique_evaluation": 856, "fraction_of_budget": 0.214}, {"seed": 20260912, "unique_evaluation": 905, "fraction_of_budget": 0.22625}]}

## Budget summaries

- `outer_ports` / 500: best primary=2.4844268674440535, median primary=2.60619958317328
- `outer_ports` / 1000: best primary=2.338780348920032, median primary=2.57114424184789
- `outer_ports` / 2000: best primary=2.3295495589356334, median primary=2.3639261294437826
- `outer_ports` / 4000: best primary=2.2957124233502495, median primary=2.363791233678613
- `center_outer_same` / 500: best primary=1.8966838370325307, median primary=1.993523598949345
- `center_outer_same` / 1000: best primary=1.83781807084099, median primary=1.9324605606365224
- `center_outer_same` / 2000: best primary=1.783385368521794, median primary=1.8580546670050526
- `center_outer_same` / 4000: best primary=1.779547002022388, median primary=1.827215714326797

## Runtime and validation

- Last significant improvement location is recorded in every trial JSON.
- Performance-gate speedup: `{"outer_ports": 1.9083184632774788, "center_outer_same": 1.3582690718810244}`
- Wall time: 2252.629543066025 s
- Solved frequency point counts and logging I/O time are in `convergence_trials.csv`.
- Test status: `{"passed": 42, "failed": 0, "skipped": 0, "exit_code": 0, "elapsed_s": 54.506, "runner": "unittest (pytest unavailable in bundled runtime)"}`; exact output is `tests/pytest.txt`.

## Known limitations

- Hypothetical COM remains unvalidated for production design.
- Benchmark trials are cold and non-resumed; production warm resume is non-exact.
- The benchmark does not establish a global optimum.
- Production impedance/topology sweeps require review of this certificate first.
- Source hash from the run manifest: `56b8c0bd703e40838974a14b734c7e2a2a5043398a385d3b344079aaeeec6a5d`
