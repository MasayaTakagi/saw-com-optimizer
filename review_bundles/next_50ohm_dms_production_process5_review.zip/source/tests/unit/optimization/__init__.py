"""Optimizer policy unit tests."""
