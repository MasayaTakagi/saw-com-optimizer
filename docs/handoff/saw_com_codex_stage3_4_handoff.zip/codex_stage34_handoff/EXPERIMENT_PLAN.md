# Stage 3.4 Experiment Plan — 50 Ω center_outer_same boundary recovery

## Goal

Finish the 50 Ω `center_outer_same` convergence diagnosis before moving to `outer_ports` or the 20–200 Ω impedance sweep.

The previous 16k run produced a best max violation around 1.087 but remained `likely_underoptimized`. The key evidence was:

- late material improvements in some seeds near the end of the 16k budget;
- seed dispersion widened rather than collapsed;
- the three best final seeds were at `io_idt_pairs=15`, the active lower soft bound;
- an explicit test of `io_idt_pairs=10` improved 4/5 final seeds and produced a better candidate than the recorded 16k best;
- the elite boundary detector existed but was not connected to production bound expansion.

Therefore this experiment tests the corrected design-space adaptation rather than merely doubling budget again.

---

## Phase 0 — Current refactored source verification

Before implementation or patching:

1. record current commit and dirty state;
2. locate canonical continuation/bound code after the refactor;
3. confirm whether old Stage-number modules are compatibility wrappers;
4. never put new behavior into an obsolete wrapper;
5. record current test count and baseline failures;
6. verify the existing zero-progress/diversification characterization remains present.

Abort if current code cannot be mapped unambiguously.

---

## Phase 1 — Implement Stage 3.4 policy changes

Implement only:

- elite probe → multi-seed consensus → bound expansion;
- richer probe diagnostics;
- denser checkpoint schedule;
- minimum convergence budget 16k;
- duplicate/stagnation recovery using existing population refresh semantics;
- event/log/report fields required for review.

Do not modify COM physics or optimizer family.

---

## Phase 2 — Targeted tests and full regression

Targeted synthetic tests must prove:

- elite requests do not directly expand;
- consensus can expand;
- one seed cannot expand;
- hard bounds hold;
- 15/16 count as lower-bound zone when lower=15;
- duplicate recovery is interval-based and capped;
- no double diversity injection at a bound-expansion checkpoint;
- minimum convergence budget blocks premature stop;
- current zero-progress retry semantics remain unchanged.

Then run full regression.

If any test fails, stop. Do not launch production.

---

## Phase 3 — Small preflight

Run a short 2-seed or equivalent deterministic continuation smoke using the new coordinator.

Verify:

- requested unique budget is consumed;
- process serialization/resume works;
- event JSON is serializable;
- source hash remains frozen;
- review bundle self-test passes;
- no compatibility wrapper is accidentally acting as the canonical implementation.

The smoke does not need to prove physical improvement.

---

## Phase 4 — Production experiment

### Fixed conditions

```text
Zs = Zl = 50 Ω
wiring = center_outer_same
optimizer = Legacy SciPy DE
cold seeds = 5
process workers = 5
BLAS threads/process = 1
```

### Checkpoints

```text
500
1000
2000
3000
4000
6000
8000
10000
12000
14000
16000
```

Optional escalation:

```text
32000
```

Do not declare convergence before 16000 in this specific experiment even if a temporary plateau appears.

### Bound logic

Monitor at every checkpoint.

Normal path:

```text
persistent multi-seed boundary pressure
 -> probe
 -> positive
 -> expand
```

Elite path:

```text
materially better elite at boundary
 -> probe next step across all five seeds
 -> >=2 positive seeds
 -> >=50% positive
 -> median improvement > 0.02
 -> expand
```

Expected lower sequence for `io_idt_pairs`:

```text
20 -> 15 -> 10 -> 8 hard lower limit
```

The experiment does not force these expansions; evidence must trigger them.

After expansion:

- increment design-space version;
- preserve the incumbent/population core;
- inject ~20% into newly opened region;
- reset convergence evidence for the new version;
- reset interval duplicate diagnostics.

### Duplicate recovery

At checkpoints, if an interval has:

- >=80% cache-hit/duplicate rate;
- >=500 objective calls in the interval;
- >=2000 unique evaluations since significant improvement;
- fewer than two recoveries in this design-space version;

refresh diversity using the existing continuation population recovery.

Do not do this if a bound expansion already injected diversity at that checkpoint.

---

## Phase 5 — Review bundle

Create a self-contained review bundle with at least:

- exact current source snapshot;
- fresh Stage 3.4 patch from the post-refactor tree;
- current git commit/diff/status;
- exact merged config and input text;
- all test logs;
- all checkpoint/seed trial JSON;
- boundary events including elite probes and consensus statistics;
- stagnation events;
- design-space versions;
- active bounds at each checkpoint;
- paired checkpoint improvements;
- seed IQR;
- last significant improvement;
- objective calls / unique evaluations / cache hits;
- wall time;
- final common/dense validation data;
- final polish diagnostics;
- convergence certificate.

Bundle must validate its own hashes after creation.

---

## Decision after the run

### Proceed to outer_ports if

`center_outer_same` is:

```text
converged
```

or

```text
hard_bound_limited
```

with a physically justified hard bound.

### Continue center_outer_same if

- 16k/32k still shows large paired improvement;
- seed IQR remains large;
- late improvements occur near the budget end;
- another soft-bound expansion is supported;
- duplicate recovery repeatedly finds materially new basins.

### Re-open optimizer strategy only if

32k under the corrected design space still shows clear optimizer insufficiency and not merely a moving soft bound.
