"""SAW optimizer test suite."""
