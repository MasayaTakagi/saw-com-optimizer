# Stage 3.1 review summary

This bundle contains finite cold-seed evidence only; it does not claim a global optimum.

- Command: `python -m sawopt.optimization.stage32_study --config configs/studies/stage3_2_convergence_50ohm.yaml --run runs/stage3_2_50ohm`
- Impedance: 50.0 ohm
- Budgets (unique decoded designs): None
- Wirings: ['outer_ports', 'center_outer_same']
- Cold seeds: [20260908, 20260909, 20260910, 20260911, 20260912]

## Convergence

- `outer_ports` status: `likely_underoptimized`
  - final seed IQR: 0.07308865146026111
  - common validation gap: 0.0011122817118485173
  - best-candidate polish improvement: 0.0
  - last paired median improvement: 5.801863478538394e-08
- `center_outer_same` status: `inconclusive`
  - final seed IQR: None
  - common validation gap: None
  - best-candidate polish improvement: None

## Budget summaries

- `outer_ports` / 500: best primary=2.445108550729137, median primary=2.8213706971236294
- `outer_ports` / 1000: best primary=2.298826744883449, median primary=2.5505560365254176
- `outer_ports` / 2000: best primary=1.914130328777778, median primary=1.9794810078974776
- `outer_ports` / 4000: best primary=1.8974756970892819, median primary=1.9349342253864639
- `outer_ports` / 8000: best primary=1.8973995103280181, median primary=1.9349342253864639
- `center_outer_same` / 500: best primary=1.8683497223042895, median primary=2.220372891220142
- `center_outer_same` / 1000: best primary=1.8390902198508159, median primary=1.8515167322012167
- `center_outer_same` / 2000: best primary=1.824429264817148, median primary=1.8355613742791683
- `center_outer_same` / 4000: best primary=1.4299652102237341, median primary=1.8244280904321486
- `center_outer_same` / 8000: best primary=1.4293202654733368, median primary=1.8244280903665069

## Runtime and validation

- Last significant improvement location is recorded in every trial JSON.
- Performance-gate speedup: `{}`
- Wall time: 3397.0874257087708 s
- Solved frequency point counts and logging I/O time are in `convergence_trials.csv`.
- Test status: `{"passed": 46, "failed": 0, "skipped": 0, "exit_code": 0, "elapsed_s": 54.295, "runner": "unittest (pytest unavailable in bundled runtime)"}`; exact output is `tests/unittest.txt`.

## Known limitations

- Hypothetical COM remains unvalidated for production design.
- Finite budget/seed evidence does not claim a global optimum.
- The benchmark does not establish a global optimum.
- Production impedance/topology sweeps require review of this certificate first.
- Source hash from the run manifest: `c8bebce0641be4c2374dae9affb6874b54ce68ba1cda02ea6766c7439ed5761b`
